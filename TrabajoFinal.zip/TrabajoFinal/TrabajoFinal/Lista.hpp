#pragma
#include <iostream>
using namespace std;

template <typename T>
class NodoL {
public:
    T dato;
    NodoL<T>* anterior;
    NodoL<T>* siguiente;
    NodoL(T dato, NodoL<T>* siguiente = nullptr, NodoL<T>* anterior = nullptr) {
        this->dato = dato;
        this->siguiente = siguiente;
        this->anterior = anterior;
    }
    T getDato() { return dato; }
};

template <typename T>
class ListaDobleEnlazada {
    int tam;
    NodoL<T>* primero;
    NodoL<T>* ultimo;
public:
    ListaDobleEnlazada() :tam(0), primero(nullptr), ultimo(nullptr) {}
    ~ListaDobleEnlazada(){};
    void insertarInicio(T v) {
        NodoL<T>* nuevo = new NodoL<T>(v);
        if (primero == NULL) {
            primero = nuevo;
            ultimo = nuevo;
            primero->siguiente = primero;
            primero->anterior = ultimo;
        }
        else {
            primero->anterior = nuevo;
            nuevo->siguiente = primero;
            nuevo->anterior = ultimo;
            primero = nuevo;
            ultimo->siguiente = primero;
        }
        tam++;
    }
    void insertarUltimo(T v) {
        NodoL<T>* nuevo = new NodoL<T>(v);

        if (primero == NULL) {
            primero = nuevo;
            ultimo = nuevo;
            primero->siguiente = primero;
            primero->anterior = ultimo;
        }
        else {
            ultimo->siguiente = nuevo;
            nuevo->anterior = ultimo;
            nuevo->siguiente = primero;
            ultimo = nuevo;
            primero->anterior = ultimo;
        }
        tam++;
    }
    void eliminarInicio() {
        if (tam == 0) return;
        if (tam == 1) {
            delete primero;
            primero = nullptr;
            ultimo = nullptr;
        }
        if (tam > 1) {
            NodoL<T>* aux = primero->siguiente;
            delete primero;
            primero = aux;
            primero->anterior = ultimo;
            ultimo->siguiente = primero;
        }
        tam--;
    }
    void eliminarUltimo() {
        if (tam == 0) return;
        if (tamm == 1) {
            delete primero;
            primero = nullptr;
            ultimo = nullptr;
        }
        if (tam > 1) {
            NodoL<T>* aux = ultimo->anterior;
            delete ultimo;
            ultimo = aux;
            primero->anterior = ultimo;
            ultimo->siguiente = primero;
        }
        tam--;
    }
    void mostrarLista() {
        NodoL<T>* nodo = primero;
        cout << "Doctores " << endl;
        do {
            CEspecialista* D_esp = (CEspecialista*)(nodo->dato);
            cout << D_esp->toString();
            nodo = nodo->siguiente;
            cout << "\n";
        } while (nodo != NULL);
        cout << endl;
    }
    int getTam() {
        return tam;
    }
    T getPrimero() { return primero->dato; }
    T getUltimo() { return ultimo->dato; }
    T getPorIndice(int indice) {
        NodoL<T>* aux = primero;
        for (int i = 0; i < indice; i++) {
            aux = aux->siguiente;
        }
        cout << "Especialista en el indice " << indice << ": " << endl;
        return aux->dato;
    }

};